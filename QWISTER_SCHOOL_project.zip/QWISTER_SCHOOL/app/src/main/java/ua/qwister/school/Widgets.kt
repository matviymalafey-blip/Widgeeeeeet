package ua.qwister.school
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
abstract class BaseWidget: AppWidgetProvider() {
 abstract val heading:String
 abstract val body:String
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray) {
  ids.forEach { id -> m.updateAppWidget(id, RemoteViews(c.packageName,R.layout.widget_card).apply {
   setTextViewText(R.id.widget_heading,heading); setTextViewText(R.id.widget_body,body)
  }) }
 }
}
class SchoolWidgetProvider:BaseWidget(){ override val heading="QWISTER SCHOOL · ЗАРАЗ"; override val body="Алгебра · Кабінет 402\nДо дзвінка: —\nДалі: Геометрія · 402" }
class ScheduleWidgetProvider:BaseWidget(){ override val heading="РОЗКЛАД НА ДЕНЬ"; override val body="08:00 Алгебра · 402\n08:50 Геометрія · 402\n09:45 Українська мова · 307" }
class CalculatorWidgetProvider:BaseWidget(){ override val heading="КАЛЬКУЛЯТОР"; override val body="Демонстраційний віджет. Інтерактивний калькулятор — наступний етап." }
class NotesWidgetProvider:BaseWidget(){ override val heading="НОТАТКИ"; override val body="Тут з’являтимуться твої нотатки." }
class HomeworkWidgetProvider:BaseWidget(){ override val heading="ДОМАШНІ ЗАВДАННЯ"; override val body="Поки немає збережених завдань." }
class RemindersWidgetProvider:BaseWidget(){ override val heading="НАГАДУВАННЯ"; override val body="💧 Випий води\n🏃 Розімнися\n🏠 Допоможи вдома" }
class TutorWidgetProvider:BaseWidget(){ override val heading="РЕПЕТИТОР"; override val body="Додай дату наступного заняття." }
class GameWidgetProvider:BaseWidget(){ override val heading="МІНІГРА"; override val body="Ігровий віджет буде реалізовано окремо." }
