package ua.qwister.school
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.TextView
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val page = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,36,28,28); setBackgroundColor(Color.rgb(242,247,252)) }
  fun line(s:String, size:Float, bold:Boolean=false) { page.addView(TextView(this).apply { text=s; textSize=size; setTextColor(Color.rgb(30,55,78)); if(bold) setTypeface(null,1); setPadding(0,10,0,10) }) }
  line("QWISTER SCHOOL",27f,true); line("Твій шкільний центр",17f)
  line("8 незалежних віджетів",19f,true)
  line("Головний · Розклад · Калькулятор · Нотатки",15f)
  line("Домашні завдання · Нагадування · Репетитор · Мінігра",15f)
  line("Додавай віджети через меню віджетів Samsung.",14f)
  setContentView(page)
 }
}
